1. Read the book for instruction on dependent packages installation
2. Install rtools of version 32 before loading the package devtools
3. To understand the flow of the code as well as about the functionalities please read the book