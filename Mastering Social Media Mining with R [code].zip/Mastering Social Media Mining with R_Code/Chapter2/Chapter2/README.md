SMMR_Twitter
============

Mining Opinions, Exploring Trends and More with Twitter

Use the in the following order
1. Use setwd() to the directory where all code files resides.
2. Run installAndLoadAllPackages.R. This will load all the necessary R-packages you need for this chapter
3. Modify the authenticate.R with the seceret keys and run it to build a authenticated session
4. You can either run the collectTaxiTweets.R to get latest 2000 tweets or simply load 'taxiTweets.RData' which is precomputed for you
5. Run the getSentimentOpinionLexicon.R to get the sentiments based on the english Lexicons
6. Run the getSentimentBayes.R to get sentiments using advance algorithms
7. use comparisonCloud.R to see the words clouds of the sentences/sentiments.
