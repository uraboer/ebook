SMMR_Twitter
============

Mining Opinions, Exploring Trends and More with Twitter
