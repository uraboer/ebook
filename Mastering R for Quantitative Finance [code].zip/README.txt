CSV files of chapter 3 and chapter 9 cannot be provided
Chapter 9 csv file can be purchased from http://www.bloomberg.com/