using UnityEngine;
using System.Collections;

public class Aspect : MonoBehaviour {
	public enum aspect {
		Player,
		Enemy
	}
	public aspect aspectName;
}
